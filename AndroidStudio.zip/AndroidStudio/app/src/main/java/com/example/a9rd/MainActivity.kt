
package com.example.a9rd

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    lateinit var button: Button
    lateinit var num1: TextView
    lateinit var num2: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)

        button = findViewById(R.id.button)
        num1 = findViewById(R.id.num1)
        num2 = findViewById(R.id.num2)
    }

    fun onButtonClick(view: View) {

        val a = num1.text.toString().toInt()
        val b = num2.text.toString().toInt()

        val result = a + b

        Toast.makeText(
            applicationContext,
            result.toString(),
            Toast.LENGTH_SHORT
        ).show()
    }
}
